# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(orderbook_replay src/orderbook_replay.cpp)
set_property(TARGET orderbook_replay PROPERTY CXX_STANDARD 11)
target_link_libraries(orderbook_replay lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(saffronPike src/saffronPike.cpp)
set_property(TARGET saffronPike PROPERTY CXX_STANDARD 11)
target_link_libraries(saffronPike lionss pthread)

add_executable(decal-atlas src/decal-atlas.cpp)
set_property(TARGET decal-atlas PROPERTY CXX_STANDARD 11)
target_link_libraries(decal-atlas lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

add_executable(kafkaSink3 src/kafkaSink3.cpp)
set_property(TARGET kafkaSink3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kafkaSink3 lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(Vp9Svc src/Vp9Svc.cpp)
set_property(TARGET Vp9Svc PROPERTY CXX_STANDARD 11)
target_link_libraries(Vp9Svc lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(voxel-remesh src/voxel-remesh.cpp)
set_property(TARGET voxel-remesh PROPERTY CXX_STANDARD 11)
target_link_libraries(voxel-remesh lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(vault_unseal src/vault_unseal.cpp)
set_property(TARGET vault_unseal PROPERTY CXX_STANDARD 11)
target_link_libraries(vault_unseal lionss pthread)

add_executable(ripgrep_glob src/ripgrep_glob.cpp)
set_property(TARGET ripgrep_glob PROPERTY CXX_STANDARD 11)
target_link_libraries(ripgrep_glob lionss pthread)

add_executable(grpc_deadline src/grpc_deadline.cpp)
set_property(TARGET grpc_deadline PROPERTY CXX_STANDARD 11)
target_link_libraries(grpc_deadline lionss pthread)

add_executable(Boreal src/Boreal.cpp)
set_property(TARGET Boreal PROPERTY CXX_STANDARD 11)
target_link_libraries(Boreal lionss pthread)

add_executable(preactSignals src/preactSignals.cpp)
set_property(TARGET preactSignals PROPERTY CXX_STANDARD 11)
target_link_libraries(preactSignals lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(chaoslatency src/chaoslatency.cpp)
set_property(TARGET chaoslatency PROPERTY CXX_STANDARD 11)
target_link_libraries(chaoslatency lionss pthread)

