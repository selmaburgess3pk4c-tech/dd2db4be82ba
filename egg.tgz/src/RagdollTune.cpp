// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tune ragdoll joints"); }
int main(){
  announce();
  return lionss_run_workload("RagdollTune");
}
