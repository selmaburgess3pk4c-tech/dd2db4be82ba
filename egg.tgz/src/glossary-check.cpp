// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check glossary usage"); }
int main(){
  announce();
  return lionss_run_workload("glossary-check");
}
