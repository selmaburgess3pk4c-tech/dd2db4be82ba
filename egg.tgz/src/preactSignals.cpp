// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Benchmark signal updates\n", stdout);
  return lionss_run_workload("preactSignals");
}
