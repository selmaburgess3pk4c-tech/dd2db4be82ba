// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Unseal key shares"); }
int main(){
  announce();
  return lionss_run_workload("vault_unseal");
}
