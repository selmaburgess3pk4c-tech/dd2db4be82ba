// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow boreal forest"); }
int main(){
  announce();
  return lionss_run_workload("Boreal");
}
