// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Propagate from TLE\n", stdout);
  return lionss_run_workload("tle-sgp4");
}
