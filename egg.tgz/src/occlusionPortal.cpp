// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cull via portals"); }
int main(){
  announce();
  return lionss_run_workload("occlusionPortal");
}
