// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Enter low-power mode\n", stdout);
  return lionss_run_workload("msp430lpm");
}
